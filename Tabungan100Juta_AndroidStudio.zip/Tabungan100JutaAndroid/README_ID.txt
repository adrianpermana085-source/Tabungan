TABUNGAN 100 JUTA — PROYEK ANDROID

Isi:
- Aplikasi Android WebView dengan tampilan dark gray
- Target tabungan, saldo awal, pemasukan, potongan, progres, dan riwayat
- Input nominal dalam ribuan (contoh 25 = Rp25.000)
- Penyimpanan lokal di perangkat melalui localStorage WebView
- Salin rekap melalui clipboard Android
- Ekspor rekap CSV melalui menu bagikan/simpan Android

CARA MEMBUAT APK (butuh komputer/laptop):
1. Instal Android Studio dari https://developer.android.com/studio
2. Ekstrak ZIP ini.
3. Buka Android Studio > Open > pilih folder Tabungan100Juta.
4. Tunggu Gradle Sync selesai. Jika diminta, instal Android SDK Platform 35 dan JDK yang direkomendasikan Android Studio.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Setelah selesai, klik Locate. APK debug biasanya berada di app/build/outputs/apk/debug/app-debug.apk.
7. Kirim APK ke HP iQOO Z9x, buka file APK, lalu izinkan instalasi dari sumber tersebut jika Android memintanya.

CATATAN:
- ZIP ini adalah source project Android Studio, bukan APK siap instal.
- File APK belum dapat dikompilasi di lingkungan ini karena Android SDK/Gradle build tools tidak tersedia.
- Data tabungan tersimpan lokal di aplikasi. Ekspor CSV secara berkala untuk cadangan.
