package id.tabungan.pribadi;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(23,25,28));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(23,25,28));
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(23,25,28));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new NativeBridge(), "AndroidApp");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    private class NativeBridge {
        @JavascriptInterface public void copyText(String text) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("Rekap tabungan", text));
                Toast.makeText(MainActivity.this, "Rekap berhasil disalin", Toast.LENGTH_SHORT).show();
            });
        }
        @JavascriptInterface public void exportCsv(String csv) {
            runOnUiThread(() -> {
                try {
                    File out = new File(getCacheDir(), "rekap-tabungan.csv");
                    try (FileOutputStream stream = new FileOutputStream(out)) {
                        stream.write(("\ufeff" + csv).getBytes(StandardCharsets.UTF_8));
                    }
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, "id.tabungan.pribadi.fileprovider", out);
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/csv");
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(send, "Simpan atau bagikan rekap tabungan"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Gagal menyiapkan CSV", Toast.LENGTH_LONG).show();
                }
            });
        }
    }
}
